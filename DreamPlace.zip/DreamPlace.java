public class DreamPlace{
    private String NameOfPlace;

     DreamPlace( ) { 
		 System.out.println("A Destination you aspire to Visit");
		 System.out.println("======================================");
    }
    public String getNameOfPlace() {
        return NameOfPlace;
    }
    public void setNameOfPlace(String NameOfPlace) {
        this.NameOfPlace = NameOfPlace;
    }
}