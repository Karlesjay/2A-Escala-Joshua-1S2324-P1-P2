import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		DreamPlace place = new DreamPlace(); 
		
		System.out.print("Input The Place: "); 
		place.setNameOfPlace(input.nextLine()); 
		System.out.println("Hello Dear... Welcome to "+place.getNameOfPlace());
		System.out.println("======================================");
		System.out.print("If you dream high, don't settle for less.\nCode your way to the stars; the universe is your compiler.");

	}
}